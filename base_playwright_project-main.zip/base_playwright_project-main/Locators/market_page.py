class Market:
    ADD_TO_CART = "button.btn"
    FOLLOW_TO_BASKET = "[id='shopping_cart_container']"