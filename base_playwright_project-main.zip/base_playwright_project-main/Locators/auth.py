class Auth:
    USERNAME_INPUT = "[data-test = 'username']"
    PASSWORD_INPUT = "[data-test='password']"
    LOGIN_BTN = "[data-test='login-button']"